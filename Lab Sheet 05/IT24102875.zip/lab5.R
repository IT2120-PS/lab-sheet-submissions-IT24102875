





















setwd("C:\\Users\\it24102875\\Desktop\\Lab 5\\Lab 05-20250829")
getwd()

#Q1
# Import dataset
delivery_Times <- read.csv("Exercise - Lab 05.txt", header = TRUE)

# Check first few rows
head(delivery_Times)
fix(delivery_Times)
attach(delivery_Times)

#Q2
hist(delivery_Times$Delivery_Time,
     main = "Histogram of Delivery Times",
     breaks = seq(20,70,length = 10),
     right = TRUE
     )

Q4
freq_table <- table(cut(delivery_data$Delivery_Time, breaks = breaks, right = FALSE))
cum_freq <- cumsum(freq_table)

plot(breaks[-1], cum_freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Upper Class Boundary",
     ylab = "Cumulative Frequency")






































